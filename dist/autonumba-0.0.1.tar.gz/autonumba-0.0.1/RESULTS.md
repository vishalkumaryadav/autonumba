# 🚀 autonumba Benchmark Results per Activity

| Activity | Original 🐍 (s) | Boosted 🔥 (s) | Faster % | Speed-up | Winner |
|----------|----------------|----------------|-----------|----------|--------|
| Matrix multiply | 0.0812 | 0.4095 | -404.10% | 0.20x | Original 🐍 |
| Fibonacci | 1.3740 | 0.0620 | 95.49% | 22.15x | Boosted 🔥 |
| Heavy loop | 0.0656 | 0.0076 | 88.42% | 8.64x | Boosted 🔥 |

## 📝 Original 🐍 Output
```
Running heavy Python demo...
Matrix multiply sum: 254041.72334108455
Matrix multiply done in 0.08123636245727539 seconds

Fibonacci(35): 9227465
Fibonacci done in 1.3739807605743408 seconds

Heavy loop result: 273584229
Heavy loop done in 0.0655527114868164 seconds


```

## 📝 Boosted 🔥 Output
```
Running heavy Python demo...
Matrix multiply sum: 248702.1840926794
Matrix multiply done in 0.40951108932495117 seconds

Fibonacci(35): 9227465
Fibonacci done in 0.06203269958496094 seconds

Heavy loop result: 273584229
Heavy loop done in 0.007590532302856445 seconds


```

