# autonumba 🚀

Autonumba is an aggressive auto-JIT tool that scans Python code and injects `@njit` everywhere it safely can, with optional ahead-of-time (AOT) compilation into native binaries.

## Features ✨

* ⚡ Automatic AOT compilation for instant native speed
* 📂 Boost folders, single files, or installed libraries
* 🏷️ `@libname` syntax for site-packages
* ❌ `exclude.txt` support for skipping files
* ⚙️ Configurable Numba flags
* 🖥️ CLI-first, fast, and clean workflow

## Usage 📝

Boost a folder:

```bash
python -m autonumba src -c -f -p -n -b
```

Boost a single file:

```bash
python -m autonumba main.py -c -f
```

Boost installed library:

```bash
python -m autonumba @mylib -c -f -p
```

In-place modification:

```bash
python -m autonumba src -i -c -f -p -n -b
```

Enable ahead-of-time compilation:

```bash
python -m autonumba src --aot
```

## Flags 🏷️

* `-c` / `--cache` 💾
* `-f` / `--fastmath` ⚡
* `-p` / `--parallel` 🔀
* `-n` / `--nogil` 🛠
* `-b` / `--boundscheck` 📏

Flags are **enabled by default**. Pass flags to selectively override.

## Warning ⚠️

This tool assumes numeric-heavy code. Dynamic Python, strings, IO, and objects may not compile correctly.

Use responsibly. Native binaries are fast, but dynamic features may break.

## GitHub Stats 📊

![GitHub Stats](https://github-readme-stats-fast.vercel.app/api/pin/?username=pro-grammer-SD\&repo=autonumba\&theme=radical)

![GitHub Stats](https://github-readme-stats-fast.vercel.app/api?username=pro-grammer-SD\&show_icons=true\&theme=radical)

## Fun Badges 🎉

![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)
